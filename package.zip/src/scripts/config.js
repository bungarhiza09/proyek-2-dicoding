const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  BASE_PATH: process.env.PUBLIC_PATH || '/',
  DEPLOYED_URL: 'https://mariosijabat.github.io/berbagi-cerita/',
  PUSH_MSG_VAPID_PUBLIC_KEY: 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk',
};

export default CONFIG;
